<?php
defined('MOODLE_INTERNAL') || die();
$plugin->component = 'local_cloudsupport';
$plugin->version = 2025052210;
$plugin->requires = 2022041900;
$plugin->maturity = MATURITY_STABLE;
$plugin->release = '1.0';
