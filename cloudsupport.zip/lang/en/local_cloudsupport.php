<?php
// English strings for local_course_restore
$string['pluginname'] = 'Cloud Support Tool';
$string['privacy:metadata'] = 'This plugin does not store any personal data.';
$string['eventquiztimeupdated'] = 'Quiz timing was updated';
